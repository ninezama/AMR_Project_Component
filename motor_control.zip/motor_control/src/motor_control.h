// motor_control.h
#ifndef motor_control_h
#define motor_control_h

#include <Arduino.h>

class motor_control{
  private:
    uint8_t PWM_PIN;
    uint8_t DIR_PIN;
    uint8_t EncoderA_PIN;
    uint8_t EncoderB_PIN;
    uint8_t PWM_CHANNEL;
    bool stop;
	bool Encode_Enable;
    volatile int32_t Encoder_Counter;
	int CPR;
	
  public:

    motor_control(uint8_t PWM_PIN,uint8_t PWM_CHANNEL,uint8_t DIR_PIN,uint8_t EncoderA_PIN,uint8_t EncoderB_PIN,int CPR);
	motor_control(uint8_t PWM_PIN,uint8_t PWM_CHANNEL,uint8_t DIR_PIN);
    void init();
    void encoder_count();
	void encoder_init();
    void move(int16_t pwm);// -255 to 255 :: negative for move backward, positive for move forward: size of value will be PWM    
    void motor_stop();
    void motor_start();
    void setPWM_PIN(uint8_t PIN);
    void setDIR_PIN(uint8_t PIN);
    void setEncoderA_PIN(uint8_t PIN);
    void setEncoderB_PIN(uint8_t PIN);
    void setPWM_CHANNEL(uint8_t channel);
    void setEncoder_Counter(volatile int32_t counter);
	


	double calRPM(float wheel_diameter,float gear_ratio,uint64_t time_diff,bool reset_count);
	double calVelocity(float wheel_diameter,float gear_ratio,uint64_t time_diff,bool reset_count);
	
    uint8_t getPWM_PIN();
    uint8_t getDIR_PIN();
    uint8_t getEncoderA_PIN();
    uint8_t getEncoderB_PIN();
    uint8_t getPWM_CHANNEL();
    volatile int32_t getEncoder_Counter();
    
};
#endif