// motor_control.cpp
#include "motor_control.h"
#include "Arduino.h"
motor_control::motor_control(uint8_t PWM_PIN,uint8_t PWM_CHANNEL,uint8_t DIR_PIN)
{
  this->PWM_PIN = PWM_PIN;
  this->DIR_PIN = DIR_PIN;
  this->PWM_CHANNEL = PWM_CHANNEL;
  this->stop = true;
  this->Encode_Enable = false;
}
motor_control::motor_control(uint8_t PWM_PIN,uint8_t PWM_CHANNEL,uint8_t DIR_PIN,uint8_t EncoderA_PIN,uint8_t EncoderB_PIN,int CPR)
{
  this->PWM_PIN = PWM_PIN;
  this->DIR_PIN = DIR_PIN;
  this->CPR = CPR;
  this->EncoderA_PIN = EncoderA_PIN;
  this->EncoderB_PIN =  EncoderB_PIN;
  this->PWM_CHANNEL = PWM_CHANNEL;
  this->Encode_Enable = true;
  this->stop = true;
  this->Encoder_Counter = 0;
}

void motor_control::init()
{
  ledcSetup(this->PWM_CHANNEL, 5000, 8);
  ledcAttachPin(this->PWM_PIN,this->PWM_CHANNEL);
  pinMode(this->DIR_PIN,OUTPUT);
  pinMode(this->EncoderA_PIN,INPUT_PULLUP);
  pinMode(this->EncoderB_PIN,INPUT_PULLUP);
}

void motor_control::move(int16_t pwm)
{
  if (!this->stop)
    if (pwm >= 0)
    {
      digitalWrite(this->DIR_PIN,LOW);
      ledcWrite(this->PWM_CHANNEL, abs(pwm));
    }
    else
    {
      digitalWrite(this->DIR_PIN,HIGH);
      ledcWrite(this->PWM_CHANNEL, abs(pwm));
    }
}

void motor_control::motor_start()
{
  this->stop = false;
}
void motor_control::motor_stop()
{
  this->stop = true; 
}

void motor_control::encoder_count()
{
  if (this->Encode_Enable)
	  if (digitalRead(this->EncoderB_PIN) == 1)
		this->Encoder_Counter += 1;
	  else
		this->Encoder_Counter -= 1;
}

double motor_control::calRPM(float wheel_diameter,float gear_ratio,uint64_t time_diff,bool reset_count)
{
	volatile int32_t count = this->Encoder_Counter;
	if (reset_count)
		this->Encoder_Counter = 0;
	return (double(count*1.0/time_diff*60*1000000)/(this->CPR*gear_ratio));
}

double motor_control::calVelocity(float wheel_diameter,float gear_ratio,uint64_t time_diff,bool reset_count)
{
	volatile int32_t count = this->Encoder_Counter;
	if (reset_count)
		this->Encoder_Counter = 0;
	return (double(count*1.0/time_diff*1000000)/(this->CPR*gear_ratio))*(3.1415926535897932384626433832795*wheel_diameter);
}


uint8_t motor_control::getPWM_PIN(){return this->PWM_PIN;}
uint8_t motor_control::getDIR_PIN(){return this->DIR_PIN;}
uint8_t motor_control::getEncoderA_PIN(){return this->EncoderA_PIN;}
uint8_t motor_control::getEncoderB_PIN(){return this->EncoderB_PIN;}
uint8_t motor_control::getPWM_CHANNEL(){return this->PWM_CHANNEL;}
volatile int32_t motor_control::getEncoder_Counter(){return this->Encoder_Counter;}

void motor_control::setPWM_PIN(uint8_t PIN){this->PWM_PIN = PIN;}
void motor_control::setDIR_PIN(uint8_t PIN){this->DIR_PIN = PIN;}
void motor_control::setEncoderA_PIN(uint8_t PIN){this->EncoderA_PIN = PIN;}
void motor_control::setEncoderB_PIN(uint8_t PIN){this->EncoderB_PIN = PIN;}
void motor_control::setPWM_CHANNEL(uint8_t channel){this->PWM_CHANNEL = channel;}
void motor_control::setEncoder_Counter(volatile int32_t counter){this->Encoder_Counter = counter;}